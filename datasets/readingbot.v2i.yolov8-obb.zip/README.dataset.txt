# readingbot > 2025-03-16 4:15pm
https://universe.roboflow.com/v-g2f94/readingbot-bhtza

Provided by a Roboflow user
License: Public Domain

